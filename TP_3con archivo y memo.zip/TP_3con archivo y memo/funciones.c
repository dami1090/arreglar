#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <ctype.h>
#include "funciones.h"
#include "utn.h"

int agregarPelicula(EMovie** movie,int* index)
{
    int resul=0;
    int indice;
    int indiceAux;
    int flag=2;
    int aux=0;
    char numeros[15];
    char letra = 'n';
    char preguntarSalir= 'n';
    EMovie* movieAux;
    EMovie* lista;

    EMovie* movieAuxmemo=(EMovie*)malloc(sizeof(EMovie));
    if(movieAuxmemo!=NULL)
    {
        movieAux=movieAuxmemo;
    }
    else
    {
        printf("no hay espacio para crear array auxiliar\n");
    }
    indice=*index;
    do
    {
        aux=getStringAlfanumerico("ingrese el titulo de la pelicula\n",movieAux->titulo);
        if(aux!=1 || (strlen(movieAux->titulo)>20))
        {
            printf("\n titulo incorrecto,recuerde utilizar unicamente numeros o letras,\nNi excederse de 20 caracteres\n\n");
        }
    }
    while(aux!=1 || (strlen(movieAux->titulo)>20));

    do
    {
        aux=getStringLetras("ingrese el genero de la pelicula\n",movieAux->genero);
        if(aux!=1 || (strlen(movieAux->genero)>20))
        {
            printf("\n genero incorrecto,recuerde utilizar unicamente letras,\nNi excederse de 20 caracteres\n\n");
        }
    }
    while(aux!=1 || (strlen(movieAux->genero)>20));

    do
    {
        aux=getStringDescripcion("ingrese descripcion para la pelicula\n",movieAux->descripcion);
        if(aux!=1 || (strlen(movieAux->descripcion)>50))
        {
            printf("\n descripcion incorrecta, recuerde utilizar unicamente numeros o letras,\nNi excederse de 50 caracteres\n\n");
        }
    }
    while(aux!=1 || (strlen(movieAux->descripcion)>50));

    do
    {
        aux=getStringNumeros("ingrese duracion de la pelicula en minutos\n",numeros);
        if(aux!=1)
        {
            printf("\n duracion incorrecta, recuerde utilizar solo numeros,\n ejemplo: una hora y media = 90\n\n");
        }
        else
        {
            movieAux->duracion=atoi(numeros);
        }
    }
    while(aux!=1);

    do
    {
        aux=getStringFloat("ingrese el puntaje de la pelicula,0.0 a 10\n",numeros);
        if(aux!=1)
        {
            printf("\n puntaje incorrecta, recuerde utilizar solo numeros y un punto para los decimales,\n ejemplo: 7.6 \n\n");
        }
        else
        {
            if(atof(numeros)<0 || atof(numeros)>10)
            {
                printf("\n puntaje incorrecta, recuerde utilizar solo numeros y un punto para los decimales,\n ejemplo: 7.6 \n\n");
                aux=2;
            }
            else
            {
                movieAux->puntaje=atof(numeros);
            }
        }
    }
    while(aux!=1);
    do
    {
        getString("ingrese la URL de la imagen de la pelicula\n",movieAux->linkImagen);
        printf("\n%s\nes correcta esa URL? [s|n]",movieAux->linkImagen);
        setbuf(stdin,NULL);
        scanf("%c",&letra);
        letra=tolower(letra);
    }
    while(letra!='s');
    movieAux->estado=1;

    printf("\ntitulo: %s\ngenero: %s\ndescripcion: %s\nduracion: %d\npuntaje: %.1f\nURL: %s\nLos datos son correcto y desea guardar la pelicula? [s|n]\n",movieAux->titulo,movieAux->genero,movieAux->descripcion,movieAux->duracion,movieAux->puntaje,movieAux->linkImagen);
    setbuf(stdin,NULL);
    scanf("%c",&preguntarSalir);
    preguntarSalir=tolower(preguntarSalir);
    if(preguntarSalir=='s')
    {
        if(indice==0)
        {
            //movie[indice]=*movieAux;
            indice=indice+2;
            flag=1;
        }
        else
        {
            indice++;
        }
// incrementamos el tama�o del array
        movieAuxmemo=/*(EMovie)*/realloc(*(movie),sizeof(EMovie*)*indice);
        if(movieAuxmemo!=NULL)
        {
            lista=movieAuxmemo;
            printf("lista dir:%p\n",&lista);
        }
        else
        {
            printf("no hay memoria para redimensionar el array de punteros\n");
        }
        //(movie + indice) = movieAux;
        if(flag!=1)
        {
            indiceAux = indice-2;
            lista[indiceAux]= *movieAux;
        }
        else
        {
            lista = movieAux;
        }
        //printf("1titulo:%s\n",(*(movie+indice)).titulo);
        //printf("1duracion:%d\n",(*(movie+indice)).duracion);
        //printf("1indice:%d\n",indice);
        //indice++;

        resul=1;
    }
    movie =&lista;
    printf("titulo lista:%s---dir:%p\n",lista->titulo,&lista);
    printf("titulo movie:%s---dir:%p---apunta:%p\n",(*movie)->titulo,&movie,movie);
    *index=indice;
    printf("index:%d\tindice:%d\n\n",*index,indice);
    return resul;
}

void mostrar(EMovie* movieAux)
{
    printf("\ntitulo: %s\ngenero: %s\ndescripcion: %s\nduracion: %d\npuntaje: %.1f\nURL: %s\n\n",(movieAux)->titulo,(movieAux)->genero,(movieAux)->descripcion,(movieAux)->duracion,(movieAux)->puntaje,(movieAux)->linkImagen);
    return;
}

void mostrarMuchos(EMovie** lista,int tam)
{
    int i;

    for(i=0; i<(tam-1); i++)
    {
        if((*(lista+i))->estado ==1)
        {
            mostrar((*(lista+i)));
        }

    }
    return;
}

EMovie* cargarDesdeArchivo(EMovie** movie,int* tam)
{
    int index=0;
    int acu=0;
    int flag=1;
    EMovie* aux;
    EMovie* aux2;
    FILE *f;

    f=fopen("pelis.dat", "rb");
    if(f==NULL)
    {
        f= fopen("pelis.dat", "wb");
        if(f==NULL)
        {
            printf("\n\tEl archivo no puede ser creado\n\n");
        }
        printf("\n\tse creo el archivo con exito\n\n");
        flag=0;
    }
    if(flag ==1)
    {
        while(!feof(f))
        {
            fread(*(movie+index),sizeof(EMovie),1,f);

            if(acu==0)
            {
                acu=acu+2;
            }
            else
            {
                acu++;
            }
            aux=realloc(movie,sizeof(EMovie)*acu);
            if(aux!=NULL)
            {
                aux2=aux;
            }
            if(feof(f))
            {
                printf("\n\tSe cargaron las estructuras con exito\n\n");
                break;
            }

            index++;
        }

    }

    *tam=index;
    fclose(f);
    return aux2;
}
