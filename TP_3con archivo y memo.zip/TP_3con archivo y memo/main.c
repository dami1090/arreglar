#include <stdio.h>
#include <stdlib.h>
#include "funciones.h"


int main()
{
    int longitud=0;
    char seguir='s';
    int opcion=0;
    int resul=0;

    EMovie **movie;
    EMovie **movieAux;

    movieAux=(EMovie**)malloc(sizeof(EMovie*));
    if(movieAux!=NULL)
    {
        movie=movieAux;
    }
    else
    {
        printf("no se pudo crear espacio en memoria\n");
        exit(0);
    }

    movie=cargarDesdeArchivo(movie,&longitud);

	system("pause");
	system("cls");

    while(seguir=='s')
    {
        printf("1- Agregar pelicula\n");
        printf("2- Borrar pelicula\n");
        printf("3- Generar pagina web\n");
        printf("4- Salir\n");

        setbuf(stdin,NULL);
        scanf("%d",&opcion);

        switch(opcion)
        {
            case 1:
               resul=agregarPelicula(movie,&longitud);
               if(resul!=1)
               {
                   printf("\nLa pelicula NO se guardo\n");
               }
               else
               {
                   printf("\nLa pelicula se agrego correctamente\n");
               }
                break;
            case 2:
                printf("longitud:%d\n",longitud);
                printf("dir movie:%p--apunta:%p\n",&movie,movie);
                mostrarMuchos(movie,longitud);
                break;
            case 3:
               break;
            case 4:
                seguir = 'n';
                break;

                  default:
            system("cls");
            printf("\n\tOpcion invalida\n\n");
            break;
        }
        system("pause");
        system("cls");
    }

    return 0;
}
